/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int i=10;
    float f=12.5;
    char c='a';
    char str[]="hello";
    printf("i=%d",i);
     printf("f=%f",f);
     printf("c=%c",c);
     printf("str=%s\n",str);
    return 0;
}