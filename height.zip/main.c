/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int h;
   printf("enter a height");
   scanf("%d",&h);
   if(h<150)
   {
       printf("drawf");
   }
       
      else if(150<h && h<165){
     
       printf("avg");
      }
      
      else if(165<h&&h<190)
       {
       printf("tall");
       }
       else if(h>190)
       {
           printf("abnormal");
       }
       
   
   
    return 0;
}
