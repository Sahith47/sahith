/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

void main()
{
    int i,n,f1=0,f2=1,f3;
    printf("enter a vlue");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        printf("%d",f1);
         f3=f1+f2;
         f1=f2;
         f2=f3;
    
    }
    return 0;
}
