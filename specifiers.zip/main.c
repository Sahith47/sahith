/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char name[20];
    char sname[20];
    printf("enter your name");
    scanf("%s",&name);
    printf("enter your surname");
     scanf("%s",&sname);-
    
    printf("your name is %s\n",name);
    printf(" your surname %s\n",sname);

    printf("your name is %s\t",name);
    printf(" your surname %s\n",sname);

    printf("your name is %s\b",name);
    printf(" your surname %s\n",sname);

     printf("your name is %s\r",name);
    printf("your surname %s\n",sname);
 
 return 0;
}
