/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int n;
    printf("enter a val");
    scanf("%d",&n);
    
 while(n!=1)   
 {
    if(n%2==0)
    {
        n=n/2;
        
    }else
    {
        n=3*n+1;
    }
    printf("%d",n);
 }

    return 0;
}
