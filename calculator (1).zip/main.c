/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,c;
    printf("enter a value");
    scanf("%d%d",&a,&b);
    printf("enter choice");
    scanf("%d",&c);
    

switch(c)
{
case 1:printf("%d",a+b);
break;
case 2:printf("%d",a-b);
break;
case 3:printf("%d",a/b);
break;
case 4:printf("%d",a*b);
break;

default :
printf("invalid");
break;
}

    return 0;
}
