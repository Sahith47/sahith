/******************************************************************************

write a program to display

*******************************************************************************/
#include <stdio.h>

int main()
{
    int d,m,y;
    printf("enter a date");
        scanf("%d%d%d",&d,&m,&y);
        
printf("%d-%d-%d",d,m,y);
    return 0;
}
